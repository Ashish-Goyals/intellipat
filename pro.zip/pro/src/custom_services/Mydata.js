function numberSquare(number){
    console.log("Squaring will done");
    return Math.pow(number,2);
}
export {numberSquare};