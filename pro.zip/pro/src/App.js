import {BrowserRouter as Router, Routes,Route} from 'react-router-dom';
import Nav from "./components/Nav";
import Home from "./components/Home";
import Counter from "./components/Counter";
import Users from "./components/Users";
import Posts from "./components/Posts";
import Mymemo from "./components/Mymemo";
import About from "./components/About";
import Notfound from "./components/Notfound";
import Contact from './components/Contact';
import Noida from './components/Noida';
import Gurugram from './components/Gurugram';
import Banglaru from './components/Banglaru';
import Products from './components/Products';
import Myproducts from './components/Myproducts';
function App() {
  return (
    <div>
      <Router> 
       <Nav />
       <section className="container">
         {/* load component when url is match with the path  */}
         <Routes>
            <Route path='' element={<Home />}/>
            <Route path='about' element={<About />}/>
            <Route path='counter' element={<Counter />}/>
            <Route path='users' element={<Users />}/>
            <Route path='posts' element={<Posts />}/>
            <Route path='myproducts' element={<Myproducts />}/>
            <Route path='products/:cat' element={<Products />}/>
            <Route path='memo' element={<Mymemo />}/>
            <Route path='contact' element={<Contact />}>
                <Route path='noida' element={<Noida />}/>
                <Route path='gurugram' element={<Gurugram />}/>
                <Route path='bangaluru' element={<Banglaru />}/>
            </Route>
            <Route path='*' element={<Notfound /> }/> 
         </Routes>
       </section>
       </Router>
    </div>
  );
}
export default App;
