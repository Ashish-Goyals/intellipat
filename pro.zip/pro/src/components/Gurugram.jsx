import React from 'react'

export default function Gurugram() {
  return (
    <div>Gurugram</div>
  )
}
