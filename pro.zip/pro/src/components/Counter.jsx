import { useState,useEffect } from "react";
import { useSearchParams } from "react-router-dom";
const Counter=()=>{
    const [searchParams,setSearchParams]=useSearchParams();
    useEffect(()=>{
      console.log("Hii")
        let id=searchParams.get('id');
        console.log(id)
    },[])
    //define state
    const [count,setCount]=useState(0);
    const INC=()=>{
        //update the counter by +2
        setCount(count+2)
    }
    const DEC=()=>{
        //update the counter by -1
        setCount(count-1)
    }
    return(
        <>
          <h2> State counter example</h2>
          <p> The counter is {count} </p>
          <button onClick={INC}> ++ </button>
          <button onClick={DEC}> -- </button>
        </>
    )
}
export default Counter;