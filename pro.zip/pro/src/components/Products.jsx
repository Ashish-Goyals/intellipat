import React,{useEffect,useState}from 'react'
import { useParams } from 'react-router-dom'

export default function Products() {
    const [proData,setProData]=useState([]);
    const {cat}=useParams();
    useEffect(()=>{
        let data=[
            {id:1,cat:"mens",name:"A",price:456},
            {id:2,cat:"womens",name:"B",price:8456},
            {id:3,cat:"kids",name:"C",price:956},
            {id:4,cat:"womens",name:"BB",price:756},
            {id:5,cat:"kids",name:"CC",price:856},
            {id:6,cat:"mens",name:"AA",price:5456}
        ];
        let filterData=data.filter(pro=> pro.cat==cat);
        setProData(filterData);
    })
  return (
    <div>
        <h2> {cat} Products</h2>
        <ul>
            {proData.map(pro=>
                 <li key={pro.id}> {pro.name} price is {pro.price} </li>
                )}
        </ul>
    </div>
  )
}
