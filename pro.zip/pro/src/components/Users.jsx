import useFetchData from "../hooks/FetchDataHook";
const Users=()=>{
    const API="https://jsonplaceholder.typicode.com/users";
    const userData=useFetchData(API)
  return(
    <>
       <h2> Fetch users from JSON Place Holder</h2>
       <ul>
          {userData?.map(user=> 
              <li key={user.id}>{user.name}---- {user.email}</li>
            )}
       </ul>
    </>
  )
}
export default Users;