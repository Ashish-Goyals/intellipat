import React from 'react'

export default function Banglaru() {
  return (
    <div>Banglaru</div>
  )
}
