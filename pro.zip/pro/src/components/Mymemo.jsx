import { useState,useMemo } from "react";
import { numberSquare } from "../custom_services/Mydata";
const Mymemo=()=>{
    const [number,setNumber]=useState(0);
    const [counter,setCounter]=useState(0);
    //const squaredNum=numberSquare(number); // without memorization
    const squaredNum=useMemo(()=> 
    {
        return numberSquare(number)
    },[number]);
    
        ;//find square
    const handler=(event)=>{
        setNumber(event.target.value);
    }
    const INC=()=>{
        setCounter(counter+1);
    }
    return(
        <>
          <h2 className="text-center text-danger"> useMemo real time example</h2>
          <input type="text" placeholder="Enter number" onChange={handler}/> 
          <div>
              <p> Square of {number} : {squaredNum}</p>
              <button onClick={INC}> ++ </button>
              <p> Counter is {counter}</p>
          </div>
        </>
    )
}
export default Mymemo;