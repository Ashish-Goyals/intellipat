import { useEffect, useState,useContext } from "react";
import CartContext from "../context/CartContext";
const About=()=>{
  const {title,course,upDateCount}=useContext(CartContext)
  const [seconds,setSeconds]=useState(0);
  useEffect(()=>{
    //mounting
     const timerId=setInterval(()=> setSeconds(s=> s+1) ,1000);
      //unmounting 
        return ()=> clearInterval(timerId);
  },[]);
    return(
        <>
          <h2> About Page</h2>
          <p> {title} --- {course}</p>
          <p> Elapsed time : {seconds} </p>
          <button onClick={upDateCount}> Cart</button>
         
        </>
    )
}
export default About;