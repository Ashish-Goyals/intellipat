import { useContext } from "react";
import { Link } from "react-router-dom";
import CartContext from "../context/CartContext";

const Nav=()=>{
  const {title,mycount,cartData}=useContext(CartContext)
  const category=["mens","womens","kids"];
    return(
        <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
  <div className="container-fluid">
    <Link className="navbar-brand" to="/">Geek for Geek</Link>
    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span className="navbar-toggler-icon"></span>
    </button>
    <div className="collapse navbar-collapse" id="navbarNav">
      <ul className="navbar-nav">
        <li className="nav-item">
          <Link className="nav-link active" aria-current="page" to="/">Home</Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link" to="/about">About Us</Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link" to="/counter">Counter</Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link" to="/posts">Posts</Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link" to="/users">Users</Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link" to="/memo">Memo</Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link" to="/contact">Contact</Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link" to="/myproducts">Myproducts</Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link" to="/contact">Cart {cartData.length>0 && <span> ({cartData.length})</span>}</Link>
        </li>
        <li className="nav-item dropdown">
          <a className="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Category
          </a>
          <ul className="dropdown-menu" aria-labelledby="navbarDropdown">
            {category.map((cat,ind)=>
                <li key={ind}><Link className="dropdown-item" to={`/products/${cat}`}>{cat}</Link></li>
            )}
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>
    )
}
export default Nav;