import { Link } from "react-router-dom";

const Home=()=>{
    const courses=["Angular","React Js","Vue Js","Node Js","Deveops","Django"];
    return(
        <>
          <h2> Home Component</h2>
          <ul>
              {courses.map((val,ind)=>
                  <li key={ind}> {val} </li>
              )}
          </ul>
          <Link to="/counter?id=101"> Counter</Link>
        </>
    )
}
export default Home;