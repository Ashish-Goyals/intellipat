const Notfound=()=>{
  return(
    <>
      <h2> Page Not Found</h2>
    </>
  )
}
export default Notfound;