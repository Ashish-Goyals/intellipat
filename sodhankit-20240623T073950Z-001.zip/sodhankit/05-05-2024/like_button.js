'use strict';

// const likeButton = React.createElement(
//     'button',
//     { className: 'greeting', onClick: () => console.log('I like button.') },
//     'Like Button',
// );

// const divContainer = React.createElement(
//     'div',
//     { className: 'container' },
//     likeButton
// )

const divContainer = (
    <div className="container">
        <h1>Welcome to React JS</h1>
        <button className="greeting">
            Like Button With JSX
        </button>
    </div>
)

const domContainer = document.querySelector('#root');
const root = ReactDOM.createRoot(domContainer);
root.render(divContainer);
