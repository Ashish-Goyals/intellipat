class Person {
    constructor(name){
        this.name = name;
    }

    displayPerson = () => {
        console.log(`Name is ${this.name}`);
    }
}

class Employee extends Person {

    constructor(name){
        super(name);    // super class constructor
        // super.name = "";    // super class member 
    }

    displayEmployee = () => {
        console.log(`Name is ${this.name}`);
    }
}

const person = new Person("Ankit");
person.displayPerson("Testing");

const person2 = new Person();

const employee = new Employee("Ashish");
// employee.name = "Ashish";
employee.displayEmployee();