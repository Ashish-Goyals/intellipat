const addNumber = (num1, num2, cb) => {
    setTimeout(()=>{
        cb(num1 + num2);
    }, 1000 * 2)
}

// console.log("Add Numbers", addNumber(10, 20));

addNumber(10, 20, (sum) => {
    console.log("Add Numbers ",sum);
})


// callback hell
addNumber(10, 20, (sum) => {
    console.log("Add Numbers ",sum);
    addNumber(30, sum, (sum2) => {
        console.log("Add Numbers ",sum2);
        addNumber(40, sum2, (sum3) => {
            console.log("Add Numbers ",sum3);
        })
    })
})