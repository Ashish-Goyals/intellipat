const user = {
    firstName: 'Test',
    lastName: 'Testing',
    email: 'test@gmail.com',
    gender: 'Male',
    address: {
        city: "City Name"
    }
}

const { firstName, lastName, age, address: { city } } = user;
// const { city } = address;

console.log('FirstName', firstName);
console.log('LastName',lastName);
console.log('Age',age);
console.log('City',city);

const displayUserName = ({ firstName, lastName }) => {
    console.log(firstName + ' ' + lastName);
}

displayUserName(user);

const cities = ["City1", "City2", "City3"];
const [city1, city2] = cities;
console.log("City1", city1);
console.log("City2", city2);

