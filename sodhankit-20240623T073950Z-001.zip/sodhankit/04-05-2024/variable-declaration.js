var x = 10;           // global scop, re-declarable 


let letVariable = 20;       // local scope , scope variable
const constVariable = 30;   // scope variable , constant , we can not change it 


var x = 100;    // re-declaration


if(true){
    // score
    let y=10;
}

{
    // scope
}