const user = {
    firstName: 'Test',
    lastName: 'Testing',
    email: 'test@gmail.com'
}

// const userCopy = user;      // shallow copy 

// const { firstName, lastName, email } = user; 
// const userCopy = {
//     firstName, lastName, email
// }

const userCopy = { ...user,  email: 'good@gmail.com', age: 30 };   // spread operator // deep copy 

console.log("user", user);
console.log("userCopy", userCopy);

user.email = "hello@gmail.com";

console.log("After change");
console.log("user", user);
console.log("userCopy", userCopy);


// rest operator
const addition = (no1, no2, ...others) => {
    console.log(others);
    // return no1+no2;
}

// addition([]);
// addition([10])
// addition([10, 20]);
// addition([10, 20, 30]);

addition();
addition(10);
addition(10, 20);
addition(10, 20, 30, 40, 50, "Test", true);



const cities = ["City1", "City2", "City3"];
// const citiesCopy = cities;      // shallow copy
const citiesCopy = [...cities, "City6", "City7"];

console.log("Before");
console.log("Cities", cities);
console.log("CitiesCopy", citiesCopy);

citiesCopy.push("City4");

console.log("After");
console.log("Cities", cities);
console.log("CitiesCopy", citiesCopy);



// const welcomeMessage = "Welcome, "+user.firstName+" "+user.lastName+" !!! Good Evening.";

const welcomeMessage = `Welcome, ${user.firstName} ${user.lastName}. Good Evening`;
console.log(welcomeMessage);