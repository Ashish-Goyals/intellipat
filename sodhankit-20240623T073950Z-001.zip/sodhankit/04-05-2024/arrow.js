// syntax 1 
function hello1(){

}

// syntax 2 
const hello2 = function(){

}


// syntaxt 3 arrow function 
const hello3 = () => {
    // logic
}

const addNumber = (num1, num2) => num1 + num2;


setInterval(() => {
    console.log('hello');
}, 1000);

(()=>{
    console.log("Immediately Invoke function")
})()

