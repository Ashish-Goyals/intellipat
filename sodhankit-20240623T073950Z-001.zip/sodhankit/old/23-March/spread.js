/*
    spread operator => triple dot (...)
*/

const person = {
  firstName: "Sarvesh",
  lastName: "Sridharamurthy",
  email: "sarvesh@gmail.com",
};

// const personCopy = person;

/*const personCopy = {};
personCopy.firstName = person.firstName;
personCopy.lastName = person.lastName;
personCopy.email = person.email;*/

const personCopy = { ...person, address: "Indore" };

console.log("person", person);
console.log("personCopy", personCopy);

personCopy.firstName = "Sunil";
personCopy.email = "sunil@gmail.com";

console.log("After Change personCopy");
console.log("person", person);
console.log("personCopy", personCopy);

// converting object into json string
// const personJson = JSON.stringify(person);
// console.log(personJson);
// console.log(personJson.firstName);

// convert json string to oject
// const personObj = JSON.parse(personJson);

const cities = ["Pune", "Banglore", "Udaypur"];
// const citiesCopy = cities;
const citiesCopy = [...cities, "Mumbai"];

console.log("cities", cities);
console.log("citiesCopy", citiesCopy);

cities.push("Indore");
console.log("After Change");

console.log("cities", cities);
console.log("citiesCopy", citiesCopy);
