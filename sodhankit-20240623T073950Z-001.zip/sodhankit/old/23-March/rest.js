/*
    rest operator => ... (triple dot)
    it will used in function arguments
*/

const add = (num1 = 0, num2 = 0, ...numberArray) => {
  //   console.log("num1", num1);
  //   console.log("num2", num2);
  console.log(numberArray);

  let sum = num1 + num2;
  numberArray.forEach((item) => (sum += item));
  return sum;
};

// num1=10, num2 =20, numberArray=[30,40,50]
console.log("5 number sum = ", add(10, 20, 30, 40, 50));
//num1=10, num2 =20, numberArray=[30]
console.log("3 number sum = ", add(10, 20, 30));
(num1 = 10), (num2 = 20), (numberArray = [30, 40]);
console.log("4 number sum is = ", add(10, 20, 30, 40));

(num1 = undefined), (num2 = undefined), (numberArray = []);
console.log("0 number sum is = ", add()); // 0 arguments

console.log("1 number sum is = ", add(10));
console.log("2 number sum is = ", add(10, 20));
// console.log(add("Test", "newTest"));
