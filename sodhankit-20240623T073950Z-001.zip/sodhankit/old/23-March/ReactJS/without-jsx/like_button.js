// Step 3

const domContainer = document.getElementById("app");
const root = ReactDOM.createRoot(domContainer);

const e = React.createElement;
const helloWorld = e(
  "h1",
  { className: "hello" },
  "Hello ",
  e("i", null, "Sara"),
  " World!!!"
);

root.render(helloWorld);
