// Step 3

const domContainer = document.getElementById("app");
const root = ReactDOM.createRoot(domContainer);

const user = "Sara";
const helloWorld = (
  <h1 className="hello">
    Hello <i>{user}</i> World!!!
  </h1>
);

root.render(helloWorld);
