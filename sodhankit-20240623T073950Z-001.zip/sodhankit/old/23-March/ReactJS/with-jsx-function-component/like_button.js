// Step 3

const domContainer = document.getElementById("app");
const root = ReactDOM.createRoot(domContainer);

// Function Component
const HelloWorld = () => {
  return (
    <div>
      <h1>Hello From React Function Component.</h1>
    </div>
  );
};

root.render(<HelloWorld />);
