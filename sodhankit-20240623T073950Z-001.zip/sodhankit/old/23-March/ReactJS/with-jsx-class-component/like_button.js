// Step 3

const domContainer = document.getElementById("app");
const root = ReactDOM.createRoot(domContainer);

// Class Component
class HelloWorld extends React.Component {
  // render method will return some JSX
  render() {
    return (
      <div>
        <h1>Hello From React Class Component.</h1>
        <h2>Hello From React Class Component.</h2>
        <h3>Hello From React Class Component.</h3>
        <h4>Hello From React Class Component.</h4>
        <h5>Hello From React Class Component.</h5>
      </div>
    );
  }
}

root.render(<HelloWorld />);
