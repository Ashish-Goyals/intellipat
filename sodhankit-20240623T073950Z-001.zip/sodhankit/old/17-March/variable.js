if (true) {
  var numberOne = 10; // global scope
  let numberTwo = 20; // scoped variable
  const numberThree = 30; // scoped variable

  console.log("inside if numberOne = ", numberOne);
  console.log("inside if numberTwo = ", numberTwo);
  console.log("inside if numberThree = ", numberThree);

  //   numberThree = 40;
  numberOne = 40;
  numberTwo = 40;
  console.log("inside if numberOne = ", numberOne);
  console.log("inside if numberTwo = ", numberTwo);
}

console.log("numberOne = ", numberOne);
// console.log("numberTwo = ", numberTwo);
// console.log("numberThree = ", numberThree);
