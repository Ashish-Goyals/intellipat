class Employee {
  constructor(firstName, lastName) {
    console.log("Employee Constructor");
    this.firstName = firstName;
    this.lastName = lastName;
  }

  showEmployee = () => {
    console.log("Show Employee", this.firstName, this.lastName);
  };
}

class Person extends Employee {
  constructor(firstName, lastName, mobile) {
    super(firstName, lastName); // call super class constructor
    this.mobile = mobile;
    console.log("Person Constructor");
  }

  showPerson() {
    console.log("Show Person", this.firstName, this.lastName, this.mobile);
  }
}

// const emp = new Employee("Ankit", "Sodha"); // constructor get call
// emp.showEmployee();

// const empOne = new Employee();
// empOne.showEmployee();

// const empTwo = new Employee("Mayur");
// empTwo.showEmployee();

const person = new Person("Akhilesh", "Kumar", "1231231230");
// person.showEmployee();
person.showPerson();
