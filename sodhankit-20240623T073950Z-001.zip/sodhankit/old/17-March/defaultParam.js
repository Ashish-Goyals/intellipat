const SimpleInterest = (principle, noOfYear = 5, interest = 1.2) => {
  return (principle * noOfYear * interest) / 100;
};

console.log(SimpleInterest(100000, 5, 1.3));
console.log(SimpleInterest(100000, 5));
console.log(SimpleInterest(200000, 5));
console.log(SimpleInterest(300000));
console.log(SimpleInterest(400000, 6, 1.4));
console.log(SimpleInterest());
