const firstName = "Anil";
const lastName = "Kumar";

const fullName = firstName + " " + lastName;

const fullName1 = `${firstName} ${lastName}`;

const addition = `2 + 2 = ${2 + 2}`;
console.log("Addition", addition);
