const person = {
  firstName: "Preeti",
  lastName: "Sharma",
  email: "preeti@gmail.com",
  address: {
    city: "Pune",
    state: "Maharastra",
  },
};

// console.log("First Name : ", person.firstName);
// console.log("Last Name : ", person.lastName);
// console.log("Email : ", person.email);

// destructuring
const { firstName, lastName, mobile } = person;
console.log("First Name", firstName);
console.log("Last Name", lastName);
console.log("Mobile ", mobile);

const cities = ["Pune", "Mumbai", "Banglore"];
const [city1, city2, city3, city4] = cities;
console.log(city1, city2, city3, city4);

person.cities = cities;
console.log(person.cities);

// const { address } = person;
// const { city } = address;

const {
  address: { city, state },
} = person;

console.log("Person City - ", city);
console.log("Person State - ", state);
