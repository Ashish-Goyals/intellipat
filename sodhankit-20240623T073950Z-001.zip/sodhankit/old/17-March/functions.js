// syntax 1
function hello() {
  return "Hello Boss";
}

// syntax 2
const greeting = function () {
  return "Good Evening Boss";
};

// arrow function - syntax 3
/* const greetingBoss = () => {
  return "How are you Boss?";
}; */

const greetingBoss = () => "How are you Boss?";

const addTwoNumbers = (num1, num2) => num1 + num2;

const maxNumber = (num1, num2) => {
  if (num1 > num2) return num1;
  else return num2;
};

console.log(hello());
console.log(greeting());
console.log(greetingBoss());

console.log(addTwoNumbers(20, 40));
console.log(maxNumber(30, 35));
